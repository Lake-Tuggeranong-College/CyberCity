#ifndef CyberCityShareFuntionality_H
#define CyberCityShareFuntionality_H
#include <Arduino.h>

//version 1.0.0 28.03.2023

class CyberCityShareFuntionality
{
public:
    CyberCityShareFuntionality();
void commonSetup() ;
void updateEPD(String title, String dataTitle, float dataToDisplay);
void drawText(String text, uint16_t color, int textSize, int x, int y) ;

void logEvent(String dataToLog) ;
void uploadData (String dataToPost, int delayBetweenPosts) ;
private:
    String getDateAsString() ;
String getTimeAsString();
};
#endif

